import { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'
import { useApp } from '../context/AppContext'

const emptyForm = { name: '', price: '', description: '', featured: false }

export default function VendorPanel() {
  const { session } = useApp()
  const [products, setProducts]   = useState([])
  const [form, setForm]           = useState(emptyForm)
  const [editing, setEditing]     = useState(null) // product id being edited
  const [loading, setLoading]     = useState(true)
  const [saving, setSaving]       = useState(false)
  const [error, setError]         = useState('')
  const [success, setSuccess]     = useState('')

  useEffect(() => { fetchMyProducts() }, [])

  async function fetchMyProducts() {
    setLoading(true)
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('seller_id', session.user.id)
      .order('created_at', { ascending: false })

    if (!error) setProducts(data)
    setLoading(false)
  }

  function handleChange(e) {
    const val = e.target.type === 'checkbox' ? e.target.checked : e.target.value
    setForm(prev => ({ ...prev, [e.target.name]: val }))
    setError('')
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setError('')
    setSuccess('')

    const payload = {
      name: form.name.trim(),
      price: parseFloat(form.price),
      description: form.description.trim() || null,
      featured: form.featured,
      seller_id: session.user.id,
    }

    let dbError
    if (editing) {
      const { error } = await supabase
        .from('products')
        .update(payload)
        .eq('id', editing)
      dbError = error
    } else {
      const { error } = await supabase
        .from('products')
        .insert(payload)
      dbError = error
    }

    if (dbError) {
      setError('Error al guardar el producto.')
    } else {
      setSuccess(editing ? 'Producto actualizado.' : 'Producto creado.')
      setForm(emptyForm)
      setEditing(null)
      fetchMyProducts()
    }
    setSaving(false)
  }

  function startEdit(product) {
    setEditing(product.id)
    setForm({
      name: product.name,
      price: product.price,
      description: product.description || '',
      featured: product.featured || false,
    })
    setError('')
    setSuccess('')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function cancelEdit() {
    setEditing(null)
    setForm(emptyForm)
    setError('')
  }

  async function deleteProduct(id) {
    if (!confirm('¿Eliminar este producto?')) return
    await supabase.from('products').delete().eq('id', id)
    fetchMyProducts()
  }

  return (
    <div className="space-y-8">

      {/* Form */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-5">
          {editing ? 'Editar producto' : 'Nuevo producto'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nombre *</label>
              <input
                name="name" value={form.name} onChange={handleChange} required
                placeholder="Ej: Calcetines de colores"
                className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Precio *</label>
              <input
                name="price" type="number" step="0.01" min="0" value={form.price}
                onChange={handleChange} required placeholder="0.00"
                className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
            <textarea
              name="description" value={form.description} onChange={handleChange}
              placeholder="Describe tu producto..."
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 resize-none"
            />
          </div>

          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input type="checkbox" name="featured" checked={form.featured} onChange={handleChange}
              className="w-4 h-4 accent-brand-600" />
            <span className="text-sm text-gray-700">Destacar producto en Home</span>
          </label>

          {error   && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>}
          {success && <p className="text-sm text-green-700 bg-green-50 border border-green-200 rounded-lg px-3 py-2">{success}</p>}

          <div className="flex gap-3">
            <button
              type="submit" disabled={saving}
              className="bg-brand-600 hover:bg-brand-700 disabled:bg-brand-300 text-white text-sm font-medium px-5 py-2.5 rounded-lg transition-colors"
            >
              {saving ? 'Guardando...' : editing ? 'Actualizar' : 'Publicar producto'}
            </button>
            {editing && (
              <button type="button" onClick={cancelEdit}
                className="text-sm text-gray-600 hover:text-gray-800 px-4 py-2.5 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors">
                Cancelar
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Product list */}
      <div>
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Mis productos</h2>

        {loading ? (
          <p className="text-sm text-gray-400">Cargando...</p>
        ) : products.length === 0 ? (
          <p className="text-sm text-gray-400">Aún no tienes productos publicados.</p>
        ) : (
          <div className="space-y-3">
            {products.map(p => (
              <div key={p.id} className="bg-white rounded-xl border border-gray-200 px-4 py-3 flex items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-gray-800 truncate">{p.name}</p>
                    {p.featured && <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">⭐ Destacado</span>}
                  </div>
                  <p className="text-brand-600 font-bold text-sm mt-0.5">${Number(p.price).toFixed(2)}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => startEdit(p)}
                    className="text-xs text-blue-600 hover:bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg transition-colors">
                    Editar
                  </button>
                  <button onClick={() => deleteProduct(p.id)}
                    className="text-xs text-red-600 hover:bg-red-50 border border-red-200 px-3 py-1.5 rounded-lg transition-colors">
                    Eliminar
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
